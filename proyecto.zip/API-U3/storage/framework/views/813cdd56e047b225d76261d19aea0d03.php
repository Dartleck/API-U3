<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos Comprados</title>
    <style>
        /* Estilo para el contenedor de cada producto */
        .producto {
            border-bottom: 1px solid #ccc; /* Borde inferior */
            margin-bottom: 10px; /* Espacio entre productos */
            padding-bottom: 10px; /* Espacio interno inferior */
        }
    </style>
</head>
<body>

    <a href="<?php echo e(route('Cliente.home')); ?>" class="btn btn-secondary mt-3">Volver</a>

    <div class="container">
        <h1 class="my-4">Productos Comprados</h1>

        
        <?php if($productosComprados->isNotEmpty()): ?>
            
            <?php
                $totalGasto = 0;
            ?>

            
            <?php $__currentLoopData = $productosComprados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
                    $gastoProducto = $cantidadProductos[$producto->id] * $producto->price;
                    $totalGasto += $gastoProducto;
                ?>

                
                <div class="producto">
                    <p><strong>Nombre:</strong> <?php echo e($producto->name); ?></p>
                    <p><strong>Descripción:</strong> <?php echo e($producto->description); ?></p>
                    <p><strong>Precio:</strong> $<?php echo e(number_format($producto->price, 2, '.', ',')); ?></p>
                    <p><strong>Cantidad de productos comprados:</strong> <?php echo e($cantidadProductos[$producto->id]); ?></p>
                    <p><strong>Gasto total por este producto:</strong> $<?php echo e(number_format($gastoProducto, 2, '.', ',')); ?></p>

                    
                    <?php $__currentLoopData = $producto->transacciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($transaccion->comprado && $transaccion->user_id == Auth::id()): ?>
                            <form action="<?php echo e(route('Cliente.transacciones.calificar', $transaccion->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <label for="rating">Calificación:</label>
                                <select name="rating" id="rating">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                </select>
                                <button type="submit">Calificar</button>
                            </form>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <h2>Gasto Total: $<?php echo e(number_format($totalGasto, 2, '.', ',')); ?></h2>

        <?php else: ?>
            <p>No hay productos comprados.</p>
        <?php endif; ?>

    </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/productosComprados.blade.php ENDPATH**/ ?>