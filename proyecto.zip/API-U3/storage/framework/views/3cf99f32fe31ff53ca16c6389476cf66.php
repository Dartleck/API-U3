<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
</head>
<body>
    <h1>Editar Producto</h1>

    <form action="<?php echo e(route($rol . '.productos.update', $producto->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Campos para editar el producto -->
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo e($producto->name); ?>" required><br><br>

        <label for="descripcion">Descripción:</label><br>
        <textarea id="descripcion" name="descripcion" rows="4" cols="50" required><?php echo e($producto->description); ?></textarea><br><br>

        <label for="precio">Precio:</label>
        <input type="number" id="precio" name="precio" value="<?php echo e($producto->price); ?>" step="0.01" required><br><br>

        <label for="stock">Stock:</label>
        <input type="number" id="stock" name="stock" value="<?php echo e($producto->stock); ?>" required><br><br>

        <label for="confirmado">Estado:</label>
        <select id="confirmado" name="state" required onchange="toggleRazon()">
            <option value="pendiente" <?php if($producto->state == 'pendiente'): ?> selected <?php endif; ?>>Pendiente</option>
            <?php if($rol !== 'Vendedor'): ?>
                <option value="aceptado" <?php if($producto->state == 'aceptado'): ?> selected <?php endif; ?>>Aceptado</option>
                <option value="rechazado" <?php if($producto->state == 'rechazado'): ?> selected <?php endif; ?>>Rechazado</option>
            <?php endif; ?>
        </select><br><br>
        
        <?php $__errorArgs = ['estado_comprado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p style="color: red;"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <label for="razon_rechazo" id="razon_rechazo_label" style="display: none;">Razón de rechazo:</label>
        <textarea id="razon_rechazo" name="razon_rechazo" rows="4" cols="50" style="display: none;"></textarea><br><br>
        
        <script>
            function toggleRazon() {
                var state = document.getElementById('confirmado').value;
                var razonRechazoLabel = document.getElementById('razon_rechazo_label');
                var razonRechazoTextarea = document.getElementById('razon_rechazo');
        
                if (state === 'rechazado') {
                    razonRechazoLabel.style.display = 'block';
                    razonRechazoTextarea.style.display = 'block';
                } else {
                    razonRechazoLabel.style.display = 'none';
                    razonRechazoTextarea.style.display = 'none';
                }
            }
        </script>
        


        <label for="categoria_id">Categoría:</label>
        <select id="categoria_id" name="categoria_id" required>
            <!-- Iterar sobre las categorías disponibles -->
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($categoria->id); ?>" <?php if($producto->category_id == $categoria->id): ?> selected <?php endif; ?>><?php echo e($categoria->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br><br>

        <button type="submit">Actualizar Producto</button>
    </form>
    <a href="<?php echo e(route($rol.'.productos')); ?>">Volver</a>
</body>
</html>
<?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/editar_producto.blade.php ENDPATH**/ ?>