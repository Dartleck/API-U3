<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comprar Producto</title>
</head>
<body>
    <h1>Comprar Producto</h1>

    <form action="<?php echo e(route($rol.'.productos.realizarCompra', $producto->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p><strong>Nombre:</strong> <?php echo e($producto->name); ?></p>
        <p><strong>Descripción:</strong> <?php echo e($producto->description); ?></p>
        <p><strong>Precio:</strong> $<?php echo e(number_format($producto->price, 2, '.', ',')); ?></p>
        <p><strong>Stock Disponible:</strong> <?php echo e($producto->stock); ?></p>
        <p><strong>Cantidad a Comprar:</strong> <input type="number" name="cantidad" value="1" min="1" max="<?php echo e($producto->stock); ?>"></p>
        <p><strong>Vendedor:</strong> <?php echo e($producto->user->name); ?></p>
        <p><strong>Subir Voucher:</strong> <input type="file" name="voucher" required></p>
        <button type="submit">Comprar</button>
    </form>

    <a href="<?php echo e(route($rol.'.productos')); ?>">Volver a la lista de productos</a>
</body>
</html>
<?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/comprarProdcutos.blade.php ENDPATH**/ ?>