<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4 text-center">Bienvenido, <?php echo e($cliente->name); ?></h1>
        <div class="d-flex flex-column align-items-center">
            <div class="card" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Acciones Rápidas</h5>
                    <p class="card-text">Seleccione una opción para continuar.</p>
                    <div class="list-group">
                        <a href="<?php echo e(route('Cliente.productos')); ?>" class="list-group-item list-group-item-action d-flex align-items-center">
                            <i class="bi bi-box-seam me-2"></i> Ver Productos
                        </a>
                        <a href="<?php echo e(route('Cliente.productos.comprados')); ?>" class="list-group-item list-group-item-action d-flex align-items-center">
                            <i class="bi bi-cart-check me-2"></i> Mis Productos
                        </a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/cliente/home.blade.php ENDPATH**/ ?>