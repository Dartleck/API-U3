<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablero</title>
</head>
<body>
    <h1>Informes</h1>

    <div>
        <h2>Usuarios Registrados</h2>
        <p>Total: <?php echo e($totalUsuarios); ?></p>
    </div>

    <div>
        <h2>Transacciones</h2>
        <p>Total: <?php echo e($totalTransacciones); ?></p>
    </div>

    <div>
        <h2>Productos Aceptados</h2>
        <p>Total: <?php echo e($totalProductosAceptados); ?></p>
    </div>

    <div>
        <h2>Productos Pendientes</h2>
        <p>Total: <?php echo e($totalProductosPendientes); ?></p>
    </div>

    <div>
        <h2>Productos Rechazados</h2>
        <p>Total: <?php echo e($totalProductosRechazados); ?></p>
    </div>

    <br>
    <br>
    <a href="<?php echo e(route($rol.'.home')); ?>">Regresar al Home del <?php echo e(ucfirst($rol)); ?></a>
</body>
</html>
<?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/dashboard.blade.php ENDPATH**/ ?>