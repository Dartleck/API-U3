<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Productos</title>
</head>
<body>
    <div class="container">
        <h1>Mis Productos</h1>

        <form id="searchForm" action="<?php echo e(route('Vendedor.misproductos')); ?>" method="GET" class="mb-3">
            <div class="form-group">
                <label for="categoria_id">Buscar por categoría:</label>
                <select name="categoria_id" id="categoria" class="form-control" onchange="this.form.submit()">
                    <option value="">Todas las categorías</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>" <?php echo e(request('categoria_id') == $categoria->id ? 'selected' : ''); ?>><?php echo e($categoria->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Buscar</button>
        </form>

        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(request('categoria_id') == $categoria->id || request('categoria_id') == ''): ?>
                <div id="categoria<?php echo e($categoria->id); ?>" class="categoria">
                    <h2><?php echo e($categoria->name); ?></h2>
                    <div class="row">
                        <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($producto->user_id == Auth::id()): ?>
                                <div class="col-md-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($producto->name); ?></h5>
                                            <p class="card-text"><?php echo e($producto->description); ?></p>
                                            <p class="card-text">Precio: $<?php echo e(number_format($producto->price, 2, '.', ',')); ?></p>
                                            <p class="card-text">Stock: <?php echo e($producto->stock); ?></p>
                                            <p class="card-text">Estado: <?php echo e($producto->state); ?></p> <!-- Mostrar el estado del producto -->

                                            <!-- Mostrar las fotos del producto -->
                                            <?php $__currentLoopData = $producto->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <img src="<?php echo e(asset('storage/' . $foto->ruta)); ?>" alt="Foto del Producto" class="img-fluid">
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <!-- Enlaces para agregar y eliminar fotos -->
                                            <form action="<?php echo e(route('Vendedor.foto.agregar', $producto->id)); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <label for="foto">Agregar Foto:</label>
                                                    <input type="file" name="foto" id="foto" class="form-control-file">
                                                </div>
                                                <button type="submit" class="btn btn-primary">Agregar Foto</button>
                                            </form>

                                            <!-- Enlaces para editar y eliminar el producto -->
                                            <a href="<?php echo e(route('Vendedor.productos.edit', $producto->id)); ?>" class="btn btn-warning mt-2">Editar</a>
                                            <form action="<?php echo e(route('Vendedor.productos.destroy', $producto->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger mt-2">Eliminar</button>
                                            </form>

                                            <!-- Enlaces para ver y hacer preguntas -->
                                            <div class="form-group">
                                                <button class="accordion">Preguntas y Respuestas</button>
                                                <div class="form-group">
                                                    <?php if(isset($preguntasPorProducto[$producto->id]) && $preguntasPorProducto[$producto->id]->count() > 0): ?>
                                                        <ul>
                                                            <?php $__currentLoopData = $preguntasPorProducto[$producto->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li>
                                                                    <strong>Pregunta:</strong> <?php echo e($pregunta->contenido); ?>

                                                                    
                                                                    <!-- Formulario para responder la pregunta -->
                                                            <form action="<?php echo e(route($rol.'.respuestas.store', $pregunta->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <textarea name="contenido" rows="3" cols="50" required></textarea><br>
                                                                <button type="submit">Responder</button>
                                                            </form>
                                                                    <ul>
                                                                        <?php if($pregunta->respuestas !== null && $pregunta->respuestas->count() > 0): ?>
                                                                            <?php $__currentLoopData = $pregunta->respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <li>
                                                                                    <strong>Respuesta:</strong> <?php echo e($respuesta->contenido); ?>

                                                                                </li>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php else: ?>
                                                                            <li>No hay respuestas para esta pregunta.</li>
                                                                        <?php endif; ?>
                                                                    </ul>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    <?php else: ?>
                                                        <p>No hay preguntas para este producto.</p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <a href="<?php echo e(route($rol.'.preguntas.index', $producto->id)); ?>" class="btn btn-secondary mt-2">Hacer una pregunta</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">Regresar al Home</a>

    <script>
        function togglePreguntas(id) {
            var element = document.getElementById('preguntas' + id);
            element.classList.toggle('collapse');
        }
    </script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/productosv.blade.php ENDPATH**/ ?>