<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Nuevo Pago</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Crear Nuevo Pago</h1>
        <form action="<?php echo e(route('Contador.pago.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="user_id">Vendedor:</label>
                <select name="user_id" id="user_id" class="form-control">
                    <?php $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($vendedor->id); ?>"><?php echo e($vendedor->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="monto">Monto Total:</label>
                <input type="number" name="monto" id="monto" class="form-control" step="0.01" min="0.01" required>
            </div>
            <button type="submit" class="btn btn-primary">Crear Pago</button>
        </form>
        <a href="<?php echo e(route('Contador.home')); ?>" class="btn btn-secondary mt-3">Volver</a>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/contador/crear_pago.blade.php ENDPATH**/ ?>