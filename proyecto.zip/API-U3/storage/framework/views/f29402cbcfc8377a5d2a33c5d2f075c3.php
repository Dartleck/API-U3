<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
</head>
<body>
    <div class="container">
        <h1>Lista de Productos</h1>

        <form id="searchForm" action="<?php echo e(route('productos')); ?>" method="GET" class="mb-3">
            <div class="form-group">
                <label for="categoria_id">Buscar por categoría:</label>
                <select name="categoria_id" id="categoria" class="form-control" onchange="this.form.submit()">
                    <option value="">Todas las categorías</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>" <?php echo e(request('categoria_id') == $categoria->id ? 'selected' : ''); ?>><?php echo e($categoria->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Buscar</button>
        </form>

        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(request('categoria_id') == $categoria->id || request('categoria_id') == ''): ?>
                <div id="categoria<?php echo e($categoria->id); ?>" class="categoria">
                    <h2><?php echo e($categoria->name); ?></h2>
                    <div class="row">
                        <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($producto->name); ?></h5>
                                        <p class="card-text"><?php echo e($producto->description); ?></p>
                                        <p class="card-text">Precio: $<?php echo e(number_format($producto->price, 2, '.', ',')); ?></p>
                                        <p class="card-text">Stock: <?php echo e($producto->stock); ?></p>
                                        <p class="card-text">Estado: <?php echo e($producto->state); ?></p> <!-- Mostrar el estado del producto -->

                                        <!-- Mostrar las fotos del producto -->
                                        <?php $__currentLoopData = $producto->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e(asset('storage/' . $foto->ruta)); ?>" alt="Foto del Producto" class="img-fluid">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <!-- Enlaces para editar el producto para el supervisor -->
                                        <?php if(Auth::check() && Auth::user()->rol === 'Supervisor'): ?>
                                            <a href="<?php echo e(route('Supervisor.productos.edit', $producto->id)); ?>" class="btn btn-warning mt-2">Editar</a>
                                        <?php endif; ?>

                                        <!-- Enlaces para ver preguntas -->
                                        <a href="<?php echo e(route('login')); ?>" class="btn btn-warning">Ver Preguntas</a>

                                        <!-- Enlace para hacer una pregunta -->
                                        <a href="<?php echo e(route('login')); ?>" class="btn btn-secondary mt-2">Hacer una pregunta</a>

                                        <!-- Botón y sección para preguntas y respuestas -->
                                        <button class="btn btn-outline-secondary mt-2" onclick="togglePreguntas('<?php echo e($producto->id); ?>')">Ver Preguntas</button>
                                        <div id="preguntas<?php echo e($producto->id); ?>" class="collapse">
                                            <ul>
                                                <?php $__currentLoopData = $producto->preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <strong>Pregunta:</strong> <?php echo e($pregunta->contenido); ?>

                                                        <ul>
                                                            <?php $__currentLoopData = $pregunta->respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><strong>Respuesta:</strong> <?php echo e($respuesta->contenido); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">Regresar al Home</a>

    <script>
        function togglePreguntas(id) {
            var element = document.getElementById('preguntas' + id);
            element.classList.toggle('collapse');
        }
    </script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/productosa.blade.php ENDPATH**/ ?>