<!-- resources/views/vendedor/productos_comprados.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Productos Comprados</h1>

    <?php $__empty_1 = true; $__currentLoopData = $productosComprados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($producto->name); ?></h5>
                <p class="card-text"><?php echo e($producto->description); ?></p>
                <p class="card-text">Precio: $<?php echo e($producto->price); ?></p>
                <p class="card-text">Stock original: <?php echo e($producto->stock); ?></p>

                <h6>Transacciones</h6>
                <ul>
                    <?php $__currentLoopData = $producto->transacciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($transaccion->created_at); ?> - Comprado por <?php echo e($transaccion->usuario->name); ?> - Cantidad: <?php echo e($transaccion->cantidad); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <p class="card-text">Piezas restantes: <?php echo e($producto->stock - $producto->transacciones->sum('cantidad')); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No hay productos comprados.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/vendedor/productos_comprados.blade.php ENDPATH**/ ?>