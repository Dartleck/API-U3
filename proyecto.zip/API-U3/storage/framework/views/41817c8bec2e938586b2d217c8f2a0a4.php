<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
</head>
<body>
    <div class="container">
        <h1>Lista de Productos</h1>

        <form id="searchForm" action="<?php echo e(route($rol.'.productos')); ?>" method="GET" class="mb-3">
            <div class="form-group">
                <label for="categoria">Buscar por categoría:</label>
                <select name="categoria" id="categoria" class="form-control" onchange="this.form.submit()">
                    <option value="">Todas las categorías</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>" <?php echo e(request('categoria') == $categoria->id ? 'selected' : ''); ?>><?php echo e($categoria->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Buscar</button>
        </form>

        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(request('categoria') == $categoria->id || request('categoria') == ''): ?>
        <div id="categoria<?php echo e($categoria->id); ?>" class="categoria">
            <h2><?php echo e($categoria->name); ?></h2>
            <div class="row">
                <?php $__currentLoopData = $categoria->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($rol === 'Supervisor' || ($rol === 'Encargado') || ($rol === 'Vendedor' && $producto->state === 'aceptado') || ($rol === 'Cliente' && $producto->state === 'aceptado') || ($rol === 'Contador' && $producto->state === 'aceptado')): ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($producto->name); ?></h5>
                                <p class="card-text"><?php echo e($producto->description); ?></p>
                                <p class="card-text">Precio: $<?php echo e(number_format($producto->price, 2, '.', ',')); ?></p>
                                <p class="card-text">Stock: <?php echo e($producto->stock); ?></p>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-state', $producto)): ?>
                                    <p class="card-text">Estado: <?php echo e($producto->state); ?></p>
                                <?php endif; ?>

                                <!-- Mostrar las fotos del producto -->
                                <?php $__currentLoopData = $producto->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('storage/' . $foto->ruta)); ?>" alt="Foto del Producto" class="img-fluid">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- Enlace para editar el producto -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $producto)): ?>
                                    <a href="<?php echo e(route($rol.'.productos.edit', $producto->id)); ?>" class="btn btn-info">Editar</a>
                                <?php endif; ?>

                                <!-- Enlace para comprar -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('comprar', $producto)): ?>
                                    <a href="<?php echo e(route($rol.'.productos.comprar', $producto->id)); ?>" class="btn btn-success">Comprar</a>
                                <?php endif; ?>

                                <!-- Formulario para eliminar el producto -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $producto)): ?>
                                    <form action="<?php echo e(route($rol.'.productos.destroy', $producto->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                <?php endif; ?>

                                <!-- Enlace para ver kardex -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewKardex', $producto)): ?>
                                    <a href="<?php echo e(route('producto.kardex', $producto->id)); ?>" class="btn btn-warning">Ver Kardex</a>
                                <?php endif; ?>

                                <!-- Enlace para hacer una pregunta -->
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('respuesta', $producto)): ?>
                                    <a href="<?php echo e(route($rol.'.preguntas.index', $producto->id)); ?>" class="btn btn-secondary mt-2">Hacer una pregunta</a>
                                <?php endif; ?>

                                <!-- Botón y sección para preguntas y respuestas -->
                                <button class="btn btn-outline-secondary mt-2" onclick="togglePreguntas('<?php echo e($producto->id); ?>')">Ver Preguntas</button>
                                <div id="preguntas<?php echo e($producto->id); ?>" class="collapse">
                                    <ul>
                                        <?php $__currentLoopData = $producto->preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <strong>Pregunta:</strong> <?php echo e($pregunta->contenido); ?>

                                                <ul>
                                                    <?php $__currentLoopData = $pregunta->respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $respuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><strong>Respuesta:</strong> <?php echo e($respuesta->contenido); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <a href="<?php echo e(route($rol.'.home')); ?>" class="btn btn-secondary">Regresar al Home del <?php echo e(ucfirst($rol)); ?></a>

    <script>
        function togglePreguntas(id) {
            var element = document.getElementById('preguntas' + id);
            element.classList.toggle('collapse');
        }
    </script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/productos.blade.php ENDPATH**/ ?>