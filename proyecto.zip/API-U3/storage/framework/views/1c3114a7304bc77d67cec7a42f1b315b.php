<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="container mt-4">
        <h1 class="mb-3">Lista de Usuarios</h1>
    
        <?php $__currentLoopData = $usuariosPorRol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol => $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><?php echo e(ucfirst($rol)); ?></h2>
            <ul class="list-group mb-4">
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e($usuario->name); ?> - <?php echo e($usuario->email); ?>

    
                        <div class="btn-group" role="group" aria-label="User Actions">
                            <form method="GET" action="<?php echo e(route(Auth::user()->rol.'.usuarios.resetPasswordForm', $usuario->id)); ?>" class="me-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-secondary">Resetear Contraseña</button>
                            </form>
    
                            <?php if($rol === 'Vendedor'): ?>
                                <a href="<?php echo e(route('Supervisor.vendedor.historial', $usuario->id)); ?>" class="btn btn-info me-2">Ver historial</a>
                            <?php endif; ?>
    
                            <a href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>" class="btn btn-primary me-2">Editar</a>
    
                            <form method="POST" action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>" onsubmit="return confirm('¿Está seguro de que desea eliminar este usuario?');" class="me-2">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route(Auth::user()->rol.'.home')); ?>" class="btn btn-link">Regresar al home del <?php echo e(ucfirst(Auth::user()->rol)); ?></a>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/Usuarios.blade.php ENDPATH**/ ?>