<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Agregar Nueva Categoría</h1>

    <form action="<?php echo e(route('categorias.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nombre">Nombre de la categoría:</label>
            <input type="text" id="nombre" name="nombre" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Agregar Categoría</button>
    </form>

 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\brian\OneDrive\Escritorio\WEB\APP-WEB\API-U3\resources\views/agregarCategoria.blade.php ENDPATH**/ ?>